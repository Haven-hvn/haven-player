"""libtorrent Python bindings"""
import importlib.util
import sys
import os

# Load the actual module from the .so file
so_path = os.path.join(os.path.dirname(__file__), "__init__.so")
_spec = importlib.util.spec_from_file_location("libtorrent._libtorrent", so_path)
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)

# Copy all attributes to this module
for _attr in dir(_mod):
    if not _attr.startswith('_'):
        globals()[_attr] = getattr(_mod, _attr)

# Set version if available
try:
    version = _mod.version
except AttributeError:
    pass
